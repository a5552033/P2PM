dlineexpo=0.083  1hours

slotnum = 20

.csv 
flexible fixed heuristic offline