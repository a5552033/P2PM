flexible, fixed, heuristic
accept reject accept_ratio run_time

offline 
allreq_num accept run_time