reqnum_ratio = 0.4

slotnum = 60

.csv 
flexible fixed heuristic offline