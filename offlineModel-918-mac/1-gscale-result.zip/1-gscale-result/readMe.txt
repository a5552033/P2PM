Testing algorithm：
flexible fixed heuristic AGE

Testing environment：
