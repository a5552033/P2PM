IDN topo��
40DCs, each connected to 2-16 other DCs.
